# 🌍 HalalEarn ko Live Karne ka Complete Guide

Is file me step-by-step bataya gaya hai ke apni site ko **live** kaise karein —
GitHub par code push karna, hosting par deploy karna, aur apna domain `hilalearn.pk` connect karna.

---

## Step 1 — GitHub par code push karein

Ye 3 kaam **sirf aap khud** kar sakte hain (aapki apni GitHub account chahiye):

### 1a. GitHub account + naya repository banayein
1. https://github.com par account banayein (agar nahi hai)
2. **New repository** par click karein → naam rakhein `hilalearn` → **Public** rakhein → Create

### 1b. Apne computer par ye commands chalayein (project folder me)

> ⚠️ Ye project apne computer par download kar ke chalayein (workspace se copy kar ke).

```bash
cd halal-earn

# Git initialize karein (agar nahi hua)
git init

# Files add karein
git add .
git commit -m "First commit — HalalEarn marketplace"

# Apne GitHub repo se connect karein (URL apna repo ka hoga)
git remote add origin https://github.com/AAPKA_USERNAME/hilalearn.git

# Push karein
git branch -M main
git push -u origin main
```

Bas! Ab aapka poora code GitHub par hai. ✓

---

## Step 2 — Hosting par deploy karein

### ⚠️ Pehle ye samajh lein (zaroori)

Ye app **Node.js + Express** hai aur database **`db.json` file** me save hota hai.
Iska matlab: hosting aisi chahiye jo **Node server** chala sake aur **file save** rakhe.

| Hosting | Ye app chalegi? | Note |
|---|---|---|
| **Render.com** ✅ | Haan (free tier) | Recommended — Node support + persistent disk |
| **Railway.app** ✅ | Haan | Aasaan, paid credit se shuru |
| **VPS** (Hetzner/DigitalOcean) ✅ | Haan | Sab se control, thora technical |
| Vercel / Netlify ❌ | Nahi | Sirf static/serverless — file DB nahi chalega |

> **Recommendation:** **Render.com** — free, aasaan, beginner-friendly.

### Render.com par deploy (recommended)

1. https://render.com par account banayein (GitHub se signup karein)
2. **New → Web Service** par click karein
3. Apna GitHub repo **`hilalearn`** select karein
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
5. **Create Web Service** → 1-2 minute me live ho jayegi
6. Render aapko ek URL dega (jaise `https://hilalearn.onrender.com`)

---

## Step 3 — Apna domain `hilalearn.pk` connect karein

### 3a. Domain kharidein
`.pk` domain Pakistani registrars se milta hai:
- **HosterPK**, **Nexus.pk**, **WebSouls**, ya **PKNIC** se `hilalearn.pk` register karein
- Cost: lagbhag Rs. 2,000–3,500/year

### 3b. Domain ko hosting se jodein (DNS)

Render me (ya jo bhi hosting use karein):
1. **Settings → Custom Domain** me `hilalearn.pk` add karein
2. Render aapko ek **CNAME/A record** dega
3. Apne domain registrar ke **DNS settings** me wo record add karein:

```
Type: CNAME
Name: www
Value: hilalearn.onrender.com
```

Ya agar root domain (`hilalearn.pk` bina www) chahiye to A record.

4. SSL certificate auto lag jayega (HTTPS) — free.

> DNS update hone me 1 se 24 ghante lag sakte hain.

---

## Step 4 — Ads (AdSense) apply karein

Ab jab site live hai, Google AdSense ke liye apply karein:

1. https://adsense.google.com → **Sign up**
2. Apni site `https://hilalearn.pk` add karein
3. Google aapko ek code dega — usko site ke `<head>` me lagana hoga (already placeholder slots banaye hue hain)
4. Approval me kuch din se 2 hafte lag sakte hain
5. **Zaroori:** Privacy Policy + About + Contact pages bana kar site me link karein (AdSense requirement)

---

## 🚨 Zaroori note — database ka masla

Abhi database `db.json` file me hai. Iska matlab:

- **Render/Railway free tier** par kabhi kabhi server restart hone par data reset ho sakta hai
- Is liye **pehle se** ek proper database use karna behtar hai (PostgreSQL ya MongoDB)

Ye `db.json` → real database upgrade ek alag kaam hai. Jab aap deploy karne ke liye ready hon, to main ye upgrade kar ke de sakta hoon.

---

## 📋 Total checklist (live hone ke liye)

- [ ] GitHub par code push
- [ ] Render (ya hosting) par deploy
- [ ] `hilalearn.pk` domain kharidna
- [ ] DNS connect karna
- [ ] HTTPS/SSL check
- [ ] Privacy Policy + About + Contact pages
- [ ] AdSense apply
- [ ] Real database upgrade (baad me)
