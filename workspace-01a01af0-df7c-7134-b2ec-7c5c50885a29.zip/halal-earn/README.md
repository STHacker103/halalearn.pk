# HalalEarn — Full-Stack Microtask Marketplace

A commission-based, **Shariah-compliant** earning platform.
Workers earn for real work, employers get tasks done, and the platform (you, the owner)
earns a transparent **10% service fee** on every completed task.

---

## 🔑 Demo Accounts

| Role | Email | Password |
|---|---|---|
| **Admin** (owner) | `admin@halalearn.com` | `admin123` |
| **Employer** | `employer@demo.com` | `demo123` |
| **Worker** | `worker@demo.com` | `demo123` |

You can also register your own accounts from the **Log in / Sign up** page.

---

## 🧭 How the system works (roles)

### Worker
- Browses open tasks → accepts one → funds get **escrowed** (held safely)
- Does the work → submits it
- Employer approves → worker gets **90%** of the budget into their balance
- Can **withdraw** earnings (request → admin approves)

### Employer
- **Tops up** their wallet (demo: simulated deposit)
- **Posts a task** with a title, category, budget and description
- Task goes to **admin moderation** → once approved it goes **live**
- When a worker submits, employer **approves or rejects**
  - Approve → worker paid 90%, platform takes 10%
  - Reject → task reopens, funds refunded to employer

### Admin (the owner — this is where *your* earning appears)
- **Task Moderation** — approve/reject new tasks before they go live (halal check)
- **Withdrawals** — approve/reject worker payout requests
- **Users** — view all users, ban/activate accounts
- **All Tasks** — full overview of every task
- **Stats bar** — shows **Platform Commission** (your halal earning) in gold

---

## 💰 The earning model (why it's halal)

| What happens | Who earns |
|---|---|
| Task budget Rs. 2,000 completed | Worker gets **Rs. 1,800** (90%) |
| | Platform (owner) gets **Rs. 200** (10% service fee) |

- ✅ **Real payment for real work** — no lottery, no gambling (qimar)
- ✅ **Clear fixed fee (ujrat)** — a service charge for providing the platform
- ✅ **No interest (riba)**, no fake "watch ads and earn"
- ✅ **Escrow protection** for both parties

---

## 📁 File structure

```
halal-earn/
├── server.js            → Express backend + full REST API
├── db.json              → Database (auto-created; holds users, tasks, wallets)
├── package.json
└── public/
    ├── index.html       → Landing page + public task board
    ├── login.html       → Login / register
    ├── dashboard.html   → Worker & employer dashboard
    ├── admin.html       → Admin management panel
    ├── css/style.css    → Shared styling
    └── js/api.js        → Shared API + auth helpers
```

---

## 🚀 How to run it yourself

```bash
cd halal-earn
npm install        # first time only
npm start          # starts at http://localhost:3000
```

Open `http://localhost:3000` in your browser.

---

## 🔭 What's next (to make it production-ready)

1. **Real database** — replace `db.json` with PostgreSQL/MySQL/MongoDB
2. **Real payments** — integrate JazzCash / Easypaisa / bank transfer APIs
3. **File uploads** — workers attach deliverable files
4. **Ratings & reviews** — trust system between users
5. **Email verification** — confirm accounts on signup
6. **Hosting** — deploy to a VPS or cloud (the biggest step to go live)

> ⚠️ **Honest note:** This is a fully working system, but to actually *earn from it*,
> you must bring real users (workers + employers) to the platform. Building the
> software is the easy part — getting people to use it is the real work.
