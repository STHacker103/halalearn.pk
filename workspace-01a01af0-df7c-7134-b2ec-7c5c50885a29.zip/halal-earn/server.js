/**
 * HalalEarn — Full-Stack Microtask Marketplace
 * Commission-based, Shariah-compliant earning model.
 *
 * Stack: Node.js + Express, JSON-file database (no external DB needed),
 * cookie-based sessions, SHA-256 password hashing.
 */

const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;

// ---------------------------------------------------------------------------
// Database (JSON file)
// ---------------------------------------------------------------------------
const DB_PATH = path.join(__dirname, 'db.json');

function seed() {
  return {
    seq: { user: 1000, task: 1000, withdrawal: 1000, tx: 1000 },
    users: [
      {
        id: 1, name: 'Platform Admin', email: 'admin@halalearn.com', role: 'admin',
        salt: '', hash: '', balance: 0, status: 'active', createdAt: now(),
      },
      {
        id: 2, name: 'Demo Employer', email: 'employer@demo.com', role: 'employer',
        salt: '', hash: '', balance: 10000, status: 'active', createdAt: now(),
      },
      {
        id: 3, name: 'Demo Worker', email: 'worker@demo.com', role: 'worker',
        salt: '', hash: '', balance: 0, status: 'active', createdAt: now(),
      },
    ],
    tasks: [],
    withdrawals: [],
    transactions: [],
  };
}

function now() { return new Date().toISOString(); }

let db;
function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    db = seed();
    // set demo passwords
    setPassword(db.users[0], 'admin123');
    setPassword(db.users[1], 'demo123');
    setPassword(db.users[2], 'demo123');
    seedTasks();
    saveDB();
    return;
  }
  db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
  // ensure seq fields exist for older files
  if (!db.seq) db.seq = { user: 1000, task: 1000, withdrawal: 1000, tx: 1000 };
  if (!db.withdrawals) db.withdrawals = [];
  if (!db.transactions) db.transactions = [];
}
function saveDB() {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function nextId(kind) {
  db.seq[kind] = (db.seq[kind] || 1000) + 1;
  return db.seq[kind];
}

// ---------------------------------------------------------------------------
// Password hashing (SHA-256 + salt)
// ---------------------------------------------------------------------------
function hashPassword(password, salt) {
  return crypto.createHash('sha256').update(salt + password).digest('hex');
}
function setPassword(user, plain) {
  user.salt = crypto.randomBytes(16).toString('hex');
  user.hash = hashPassword(plain, user.salt);
}
function verifyPassword(user, plain) {
  return hashPassword(plain, user.salt) === user.hash;
}

// ---------------------------------------------------------------------------
// Seed tasks
// ---------------------------------------------------------------------------
function seedTasks() {
  const list = [
    { title: 'Write 50 product descriptions', cat: 'Writing', pay: 2000, desc: 'E-commerce store needs engaging product copy for 50 items.' },
    { title: 'Data entry — 500 records into Excel', cat: 'Data Entry', pay: 1500, desc: 'Name, phone and city for 500 rows, formatted cleanly.' },
    { title: 'Logo design for a new bakery', cat: 'Design', pay: 3000, desc: 'Simple, clean logo. Provide 3 initial concepts.' },
    { title: 'Translate 2 pages (Urdu → English)', cat: 'Translation', pay: 800, desc: 'Accurate, natural translation of a short document.' },
    { title: '20 Instagram captions for a clothing brand', cat: 'Writing', pay: 1000, desc: 'Creative, on-brand captions ready to publish.' },
  ];
  list.forEach(t => {
    db.tasks.push({
      id: nextId('task'),
      title: t.title, desc: t.desc, category: t.cat, budget: t.pay,
      status: 'open', // 'pending' | 'open' | 'assigned' | 'submitted' | 'completed' | 'rejected'
      employerId: 2, workerId: null,
      createdAt: now(), updatedAt: now(),
    });
  });
}

// ---------------------------------------------------------------------------
// Sessions (in-memory)
// ---------------------------------------------------------------------------
const sessions = new Map(); // token -> userId
const COOKIE = 'he_session';

function createSession(res, userId) {
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, userId);
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  });
  return token;
}
function getSessionUser(req) {
  const token = req.cookies && req.cookies[COOKIE];
  if (!token) return null;
  const userId = sessions.get(token);
  if (!userId) return null;
  return db.users.find(u => u.id === userId) || null;
}
function requireRole(role) {
  return (req, res, next) => {
    const user = getSessionUser(req);
    if (!user) return res.status(401).json({ error: 'Please log in first.' });
    if (role && user.role !== role && user.role !== 'admin') {
      return res.status(403).json({ error: 'You do not have permission for this action.' });
    }
    req.user = user;
    next();
  };
}

// ---------------------------------------------------------------------------
// Middleware
// ---------------------------------------------------------------------------
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function readCookies(req, res, next) {
  const raw = req.headers.cookie || '';
  const cookies = {};
  raw.split(';').forEach(pair => {
    const i = pair.indexOf('=');
    if (i > 0) cookies[pair.slice(0, i).trim()] = decodeURIComponent(pair.slice(i + 1).trim());
  });
  req.cookies = cookies;
  next();
}
app.use(readCookies);

// ---------------------------------------------------------------------------
// Helper: log a transaction
// ---------------------------------------------------------------------------
function addTx(userId, type, amount, desc) {
  db.transactions.push({
    id: nextId('tx'),
    userId, type, amount, desc, createdAt: now(),
  });
}

const FEE_RATE = 0.10; // platform commission

// ===========================================================================
// AUTH
// ===========================================================================
app.post('/api/register', (req, res) => {
  const { name, email, password, role } = req.body || {};
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email and password are required.' });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  }
  const r = role === 'employer' ? 'employer' : 'worker'; // only these two can self-register
  if (db.users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }
  const user = {
    id: nextId('user'),
    name, email: email.toLowerCase(), role: r,
    salt: '', hash: '', balance: 0, status: 'active', createdAt: now(),
  };
  setPassword(user, password);
  db.users.push(user);
  saveDB();
  createSession(res, user.id);
  res.json({ user: publicUser(user) });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body || {};
  const user = db.users.find(u => u.email.toLowerCase() === (email || '').toLowerCase());
  if (!user || !verifyPassword(user, password || '')) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }
  if (user.status === 'banned') {
    return res.status(403).json({ error: 'This account has been suspended. Contact support.' });
  }
  createSession(res, user.id);
  res.json({ user: publicUser(user) });
});

app.post('/api/logout', (req, res) => {
  const token = req.cookies && req.cookies[COOKIE];
  if (token) sessions.delete(token);
  res.clearCookie(COOKIE);
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  const user = getSessionUser(req);
  res.json({ user: user ? publicUser(user) : null });
});

function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, role: u.role, balance: u.balance, status: u.status, createdAt: u.createdAt };
}

// ===========================================================================
// TASKS
// ===========================================================================
app.get('/api/tasks', (req, res) => {
  const user = getSessionUser(req);
  const { status, category, mine } = req.query;

  let list = db.tasks.slice();

  if (mine && user) {
    list = list.filter(t => t.employerId === user.id || t.workerId === user.id);
  } else {
    // Public view: hide pending (awaiting moderation) from non-owners/admins
    if (!user || user.role !== 'admin') {
      list = list.filter(t => t.status !== 'pending' || t.employerId === (user && user.id));
    }
  }
  if (status) list = list.filter(t => t.status === status);
  if (category && category !== 'All') list = list.filter(t => t.category === category);

  list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ tasks: list.map(t => enrichTask(t, user)) });
});

app.get('/api/tasks/:id', (req, res) => {
  const user = getSessionUser(req);
  const t = db.tasks.find(x => x.id == req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  res.json({ task: enrichTask(t, user) });
});

function enrichTask(t, user) {
  const employer = db.users.find(u => u.id === t.employerId);
  const worker = t.workerId ? db.users.find(u => u.id === t.workerId) : null;
  return {
    ...t,
    employerName: employer ? employer.name : 'Unknown',
    workerName: worker ? worker.name : null,
    canAccept: !!user && user.role === 'worker' && t.status === 'open',
    canSubmit: !!user && user.id === t.workerId && t.status === 'assigned',
    canApprove: !!user && user.id === t.employerId && t.status === 'submitted',
    canModerate: !!user && user.role === 'admin' && t.status === 'pending',
  };
}

// Employer posts a task (goes to moderation)
app.post('/api/tasks', requireRole('employer'), (req, res) => {
  const { title, desc, category, budget } = req.body || {};
  if (!title || !budget || budget < 100) {
    return res.status(400).json({ error: 'Title and a valid budget (min Rs. 100) are required.' });
  }
  const task = {
    id: nextId('task'),
    title, desc: desc || '', category: category || 'Other',
    budget: Math.round(Number(budget)),
    status: 'pending',
    employerId: req.user.id, workerId: null,
    createdAt: now(), updatedAt: now(),
  };
  db.tasks.push(task);
  saveDB();
  res.json({ task: enrichTask(task, req.user), message: 'Task submitted for moderation.' });
});

// Admin moderation: approve (pending -> open) or reject
app.post('/api/tasks/:id/moderate', requireRole('admin'), (req, res) => {
  const t = db.tasks.find(x => x.id == req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  const { action } = req.body || {};
  if (t.status !== 'pending') return res.status(400).json({ error: 'This task is not pending moderation.' });
  if (action === 'approve') {
    // Employer must have funds (escrow)
    const employer = db.users.find(u => u.id === t.employerId);
    if (employer.balance < t.budget) {
      return res.status(400).json({ error: 'Employer has insufficient balance to fund this task.' });
    }
    t.status = 'open';
  } else if (action === 'reject') {
    t.status = 'rejected';
  } else {
    return res.status(400).json({ error: 'Invalid action.' });
  }
  t.updatedAt = now();
  saveDB();
  res.json({ task: enrichTask(t, req.user) });
});

// Worker accepts an open task (escrow: deduct from employer)
app.post('/api/tasks/:id/accept', requireRole('worker'), (req, res) => {
  const t = db.tasks.find(x => x.id == req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  if (t.status !== 'open') return res.status(400).json({ error: 'This task is no longer available.' });
  if (t.employerId === req.user.id) return res.status(400).json({ error: 'You cannot accept your own task.' });

  const employer = db.users.find(u => u.id === t.employerId);
  if (employer.balance < t.budget) {
    return res.status(400).json({ error: 'Employer has insufficient funds. Task cannot be started.' });
  }

  // Escrow: hold funds
  employer.balance -= t.budget;
  addTx(employer.id, 'escrow_hold', -t.budget, `Funds held for task #${t.id}: ${t.title}`);

  t.status = 'assigned';
  t.workerId = req.user.id;
  t.updatedAt = now();
  saveDB();
  res.json({ task: enrichTask(t, req.user) });
});

// Worker submits completed work
app.post('/api/tasks/:id/submit', requireRole('worker'), (req, res) => {
  const t = db.tasks.find(x => x.id == req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  if (t.workerId !== req.user.id) return res.status(403).json({ error: 'You are not assigned to this task.' });
  if (t.status !== 'assigned') return res.status(400).json({ error: 'Task is not in progress.' });
  t.status = 'submitted';
  t.updatedAt = now();
  saveDB();
  res.json({ task: enrichTask(t, req.user) });
});

// Employer approves submitted work -> payout + commission
app.post('/api/tasks/:id/approve', requireRole('employer'), (req, res) => {
  const t = db.tasks.find(x => x.id == req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  if (t.employerId !== req.user.id) return res.status(403).json({ error: 'You do not own this task.' });
  if (t.status !== 'submitted') return res.status(400).json({ error: 'No submitted work to approve.' });

  const fee = Math.round(t.budget * FEE_RATE);
  const payout = t.budget - fee;
  const worker = db.users.find(u => u.id === t.workerId);

  t.status = 'completed';
  t.updatedAt = now();

  // Payout to worker (90%) + platform commission (10%)
  if (worker) {
    worker.balance += payout;
    addTx(worker.id, 'earning', payout, `Payment for task #${t.id}: ${t.title}`);
  }
  addTx(t.employerId, 'escrow_release', 0, `Escrow released for task #${t.id} (worker paid, ${fee} platform fee)`);
  // platform fee is implicit; record as a transaction on admin for reporting
  const admin = db.users.find(u => u.role === 'admin');
  if (admin) addTx(admin.id, 'commission', fee, `10% service fee from task #${t.id}: ${t.title}`);

  saveDB();
  res.json({ task: enrichTask(t, req.user), payout, fee });
});

// Employer rejects submitted work -> refund escrow to employer
app.post('/api/tasks/:id/reject', requireRole('employer'), (req, res) => {
  const t = db.tasks.find(x => x.id == req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  if (t.employerId !== req.user.id) return res.status(403).json({ error: 'You do not own this task.' });
  if (t.status !== 'submitted') return res.status(400).json({ error: 'No submitted work to reject.' });

  const employer = db.users.find(u => u.id === t.employerId);
  employer.balance += t.budget;
  addTx(employer.id, 'refund', t.budget, `Escrow refunded for task #${t.id} (work rejected)`);

  t.status = 'open'; // reopen for another worker
  t.workerId = null;
  t.updatedAt = now();
  saveDB();
  res.json({ task: enrichTask(t, req.user) });
});

// Employer cancels an open task (before any worker accepts)
app.post('/api/tasks/:id/cancel', requireRole('employer'), (req, res) => {
  const t = db.tasks.find(x => x.id == req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found.' });
  if (t.employerId !== req.user.id) return res.status(403).json({ error: 'You do not own this task.' });
  if (!['pending', 'open'].includes(t.status)) return res.status(400).json({ error: 'This task cannot be cancelled now.' });
  t.status = 'rejected';
  t.updatedAt = now();
  saveDB();
  res.json({ task: enrichTask(t, req.user) });
});

// ===========================================================================
// WALLET
// ===========================================================================
// Employer deposits funds (simulated top-up)
app.post('/api/deposit', requireRole('employer'), (req, res) => {
  const amount = Math.round(Number(req.body && req.body.amount));
  if (!amount || amount < 100) return res.status(400).json({ error: 'Minimum deposit is Rs. 100.' });
  req.user.balance += amount;
  addTx(req.user.id, 'deposit', amount, 'Wallet top-up (simulated)');
  saveDB();
  res.json({ balance: req.user.balance });
});

// Worker/employer requests a withdrawal
app.post('/api/withdraw', (req, res) => {
  const user = getSessionUser(req);
  if (!user) return res.status(401).json({ error: 'Please log in first.' });
  const amount = Math.round(Number(req.body && req.body.amount));
  const method = (req.body && req.body.method) || 'Bank Transfer';
  if (!amount || amount < 100) return res.status(400).json({ error: 'Minimum withdrawal is Rs. 100.' });
  if (user.balance < amount) return res.status(400).json({ error: 'Insufficient balance.' });

  user.balance -= amount;
  addTx(user.id, 'withdraw', -amount, `Withdrawal request (${method})`);

  db.withdrawals.push({
    id: nextId('withdrawal'),
    userId: user.id,
    userName: user.name,
    amount,
    method,
    status: 'pending',
    createdAt: now(),
  });
  saveDB();
  res.json({ balance: user.balance, message: 'Withdrawal request submitted for review.' });
});

app.get('/api/transactions', requireRole(), (req, res) => {
  const list = db.transactions.filter(t => t.userId === req.user.id);
  list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ transactions: list.slice(0, 50) });
});

// ===========================================================================
// ADMIN
// ===========================================================================
function isAdmin(req, res, next) {
  const user = getSessionUser(req);
  if (!user) return res.status(401).json({ error: 'Please log in first.' });
  if (user.role !== 'admin') return res.status(403).json({ error: 'Admin access only.' });
  req.user = user;
  next();
}

app.get('/api/admin/stats', isAdmin, (req, res) => {
  const users = db.users;
  const tasks = db.tasks;
  const totalCommission = db.transactions
    .filter(t => t.type === 'commission')
    .reduce((s, t) => s + t.amount, 0);
  const totalPaidOut = db.transactions
    .filter(t => t.type === 'earning')
    .reduce((s, t) => s + t.amount, 0);

  res.json({
    users: users.length,
    workers: users.filter(u => u.role === 'worker').length,
    employers: users.filter(u => u.role === 'employer').length,
    tasks: tasks.length,
    openTasks: tasks.filter(t => t.status === 'open').length,
    completedTasks: tasks.filter(t => t.status === 'completed').length,
    pendingModeration: tasks.filter(t => t.status === 'pending').length,
    pendingWithdrawals: db.withdrawals.filter(w => w.status === 'pending').length,
    totalCommission,
    totalPaidOut,
  });
});

app.get('/api/admin/users', isAdmin, (req, res) => {
  res.json({ users: db.users.map(u => ({
    id: u.id, name: u.name, email: u.email, role: u.role,
    balance: u.balance, status: u.status, createdAt: u.createdAt,
  })) });
});

app.post('/api/admin/users/:id/status', isAdmin, (req, res) => {
  const u = db.users.find(x => x.id == req.params.id);
  if (!u) return res.status(404).json({ error: 'User not found.' });
  if (u.role === 'admin') return res.status(400).json({ error: 'Cannot change admin status.' });
  u.status = u.status === 'active' ? 'banned' : 'active';
  saveDB();
  res.json({ user: u });
});

app.get('/api/admin/withdrawals', isAdmin, (req, res) => {
  res.json({ withdrawals: db.withdrawals.slice().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) });
});

app.post('/api/admin/withdrawals/:id/resolve', isAdmin, (req, res) => {
  const w = db.withdrawals.find(x => x.id == req.params.id);
  if (!w) return res.status(404).json({ error: 'Withdrawal not found.' });
  const { action } = req.body || {};
  if (w.status !== 'pending') return res.status(400).json({ error: 'Already resolved.' });

  if (action === 'approve') {
    w.status = 'approved';
  } else if (action === 'reject') {
    w.status = 'rejected';
    // refund to user
    const u = db.users.find(x => x.id === w.userId);
    if (u) {
      u.balance += w.amount;
      addTx(u.id, 'withdraw_refund', w.amount, 'Withdrawal rejected — amount refunded');
    }
  } else {
    return res.status(400).json({ error: 'Invalid action.' });
  }
  saveDB();
  res.json({ withdrawal: w });
});

// ===========================================================================
// Fallback: serve the SPA (client-side routing via hash, so only index needed)
// ===========================================================================
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ---------------------------------------------------------------------------
loadDB();

app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ HalalEarn server running at http://0.0.0.0:${PORT}`);
  console.log('   Demo accounts:');
  console.log('   - Admin:    admin@halalearn.com / admin123');
  console.log('   - Employer: employer@demo.com  / demo123');
  console.log('   - Worker:   worker@demo.com    / demo123');
});
