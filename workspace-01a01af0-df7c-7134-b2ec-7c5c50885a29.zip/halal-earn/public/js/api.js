/**
 * HalalEarn — shared client-side helpers.
 * Handles API calls, current-user state, and UI utilities.
 */

const API = {
  // Generic fetch wrapper (JSON)
  async req(method, url, body) {
    const opts = { method, headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin' };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(url, opts);
    let data;
    try { data = await res.json(); } catch (e) { data = {}; }
    if (!res.ok) {
      const err = new Error(data.error || 'Something went wrong.');
      err.status = res.status;
      throw err;
    }
    return data;
  },

  get: (url) => API.req('GET', url),
  post: (url, body) => API.req('POST', url, body || {}),
};

// Current user (cached; refresh with refreshUser())
let currentUser = null;

async function refreshUser() {
  try {
    const { user } = await API.get('/api/me');
    currentUser = user;
  } catch (e) {
    currentUser = null;
  }
  return currentUser;
}

function logout() {
  return API.post('/api/logout').finally(() => {
    currentUser = null;
    window.location.href = 'login.html';
  });
}

// Render the shared header (nav + user chip)
function renderHeader() {
  const el = document.getElementById('header');
  if (!el) return;

  const links = [
    { href: 'index.html', label: 'Browse Tasks', page: 'index' },
    { href: 'dashboard.html', label: 'Dashboard', page: 'dashboard' },
  ];
  if (currentUser && currentUser.role === 'admin') {
    links.push({ href: 'admin.html', label: 'Admin Panel', page: 'admin' });
  }

  const currentPage = (document.body.getAttribute('data-page') || '');

  let authHtml;
  if (currentUser) {
    const initial = (currentUser.name || 'U').charAt(0).toUpperCase();
    const roleLabel = currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1);
    authHtml = `
      <div class="userchip">
        <span style="font-size:12px;color:var(--muted);">${roleLabel}</span>
        <span class="avatar-sm">${initial}</span>
        <button class="btn btn-ghost btn-sm" onclick="logout()">Log out</button>
      </div>`;
  } else {
    authHtml = `
      <a href="login.html" class="btn btn-primary btn-sm">Log in / Sign up</a>`;
  }

  el.innerHTML = `
    <div class="wrap topbar">
      <a class="brand" href="index.html"><span class="mark">H</span> HalalEarn</a>
      <nav>
        ${links.map(l => `<a href="${l.href}" class="${currentPage === l.page ? 'active' : ''}">${l.label}</a>`).join('')}
        ${authHtml}
      </nav>
    </div>`;
}

// Toast / inline alert helpers
function showAlert(id, message, type) {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = 'alert show alert-' + (type || 'error');
  el.textContent = message;
  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
}
function hideAlert(id) {
  const el = document.getElementById(id);
  if (el) el.className = 'alert';
}

// Format numbers as Pakistani rupees
const fmtRs = (n) => 'Rs. ' + Number(n || 0).toLocaleString('en-PK');
const fmtDate = (iso) => {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' });
};

const STATUS_LABEL = {
  pending: 'Pending review', open: 'Open', assigned: 'In progress',
  submitted: 'Submitted', completed: 'Completed', rejected: 'Rejected',
};
const STATUS_CLS = {
  pending: 'st-pending', open: 'st-open', assigned: 'st-assigned',
  submitted: 'st-submitted', completed: 'st-completed', rejected: 'st-rejected',
};

const CATEGORIES = ['All', 'Data Entry', 'Writing', 'Design', 'Translation', 'Other'];

// Bootstrap: load current user then render header
(async function boot() {
  await refreshUser();
  renderHeader();
})();
